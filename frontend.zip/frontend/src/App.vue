<script setup lang="ts">
import { RouterView } from 'vue-router';
import Header from '@/components/Header.vue';
import AmbientBackground from '@/components/AmbientBackground.vue';
</script>

<template>
	<AmbientBackground />
	<Header />
	<RouterView />
</template>

<style lang="scss" scoped></style>
