<script setup lang="ts">
import Input from '@/components/Input.vue';
import { RouterLink } from 'vue-router';
</script>

<template>
	<header>
		<RouterLink to="/" class="home-btn">SPWN</RouterLink>
		<div
			class="transition-all flex focus-within:h-[4rem] h-[3rem] items-center pl-2 bg-black bg-opacity-25 rounded-lg"
		>
			<label for="search">
				<svg
					xmlns="http://www.w3.org/2000/svg"
					class="h-6 w-6"
					viewBox="0 0 20 20"
					fill="white"
				>
					<path
						fill-rule="evenodd"
						d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
						clip-rule="evenodd"
					/>
				</svg>
			</label>
			<Input id="search" />
			<button
				class="h-full p-2 text-white dark:text-black bg-black dark:bg-white hover:text-black hover:bg-white hover:dark:text-white hover:dark:bg-black font-bold rounded-r-lg transition-all focus:ring focus:ring-[#e41bb3]"
			>
				Search
			</button>
		</div>
	</header>
</template>

<style lang="scss" scoped>
header {
	@apply grid grid-cols-3 shrink-0 items-center px-[3rem] w-full h-[8rem] bg-gradient-to-r from-[#00c58e]/25 to-[#e41bb3]/25;
	.home-btn {
		@apply tracking-wider flex justify-self-start text-black dark:text-white text-5xl font-bold italic transition-all focus-visible:ring focus-visible:ring-[#e41bb3] p-2 rounded-md;
		// make text glow
		@keyframes glow-light {
			0% {
				text-shadow: 0 0 0.3rem #000;
			}
			50% {
				text-shadow: 0 0 0 #000;
			}
			100% {
				text-shadow: 0 0 0.3rem #000;
			}
		}

		@keyframes glow-dark {
			0% {
				text-shadow: 0 0 0.3rem #fff;
			}
			50% {
				text-shadow: 0 0 0 #fff;
			}
			100% {
				text-shadow: 0 0 0.3rem #fff;
			}
		}

		@media (prefers-color-scheme: dark) {
			animation: glow-dark 5s ease-in-out infinite alternate;
		}

		@media (prefers-color-scheme: light) {
			animation: glow-light 5s ease-in-out infinite alternate;
		}
	}
}
</style>
