<script setup lang="ts"></script>

<template>
	<div class="bg">
		<div class="thing"></div>
	</div>
</template>

<style lang="scss" scoped>
@keyframes glow {
	0% {
		// start from center of screen
		transform: translateX(0%) translateY(-100%) rotate(0deg) scale(1);
	}
	50% {
		transform: translateY(50%) translateX(0) rotate(1turn) scale(1.2);
	}
	75% {
		transform: translateY(0%) translateX(25) rotate(2turn) scale(1.5);
	}
	100% {
		transform: translateY(60%) translateX(-25%) rotate(0deg) scale(0.95);
		background-color: #00c58e;
	}
}

.bg {
	@apply absolute flex w-full h-full overflow-hidden dark:bg-black -z-10;
	.thing {
		@apply absolute rounded-full w-3/5 inset-0 mx-auto transition-all ease-in-out blur-[100px] bg-[#e41bb3];
		animation: glow 20s ease-in-out infinite alternate;
	}
}
</style>
