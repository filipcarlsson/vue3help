<script setup lang="ts">
import { ref } from 'vue';

const props = defineProps({
	id: String,
	modelValue: String,
	iconColor: {
		type: String,
		default: 'white',
	},
});

const emit = defineEmits(['update:modelValue']);
const text = ref(props.modelValue);

const updateValue = (value: any) => {
	emit('update:modelValue', value);
	text.value = value;
};
</script>

<template>
	<div class="flex w-full h-full items-center">
		<input
			:id="props.id"
			class="flex w-full h-full bg-transparent text-white p-2 transition-all focus:text-xl"
			type="text"
			autofocus
			placeholder="Some module"
			:value="text"
			v-on:input="updateValue(($event.target as HTMLInputElement).value)"
		/>
		<transition name="fade">
			<svg
				v-if="text"
				@click="updateValue('')"
				xmlns="http://www.w3.org/2000/svg"
				class="h-6 w-6 mr-2 cursor-pointer"
				viewBox="0 0 20 20"
				:fill="props.iconColor"
			>
				<path
					fill-rule="evenodd"
					d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
					clip-rule="evenodd"
				/>
			</svg>
		</transition>
	</div>
</template>

<style lang="scss" scoped>
.fade-enter-active,
.fade-leave-active {
	@apply transition-all duration-300 ease-out;
}

.fade-enter-from,
.fade-leave-to {
	@apply scale-0;
}
</style>
