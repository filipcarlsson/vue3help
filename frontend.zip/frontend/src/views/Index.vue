<script setup lang="ts"></script>

<template>
	<main class="mx-auto">
		<h1 class="dark:text-white text-5xl font-bold mt-[4rem]">
			Welcome to SPWNPKG
		</h1>
	</main>
</template>

<style lang="scss" scoped></style>
